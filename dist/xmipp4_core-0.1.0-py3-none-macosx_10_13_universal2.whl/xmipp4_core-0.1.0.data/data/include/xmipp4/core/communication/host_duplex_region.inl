// SPDX-License-Identifier: GPL-3.0-only

#include "host_duplex_region.hpp"

#include "../numerical_type_traits.hpp"

namespace xmipp4 
{
namespace communication
{

XMIPP4_INLINE_CONSTEXPR
host_duplex_region::host_duplex_region() noexcept
	: m_send_data(nullptr)
	, m_receive_data(nullptr)
	, m_data_type(numerical_type::unknown)
	, m_count(0UL)
{
}

template <typename T>
XMIPP4_INLINE_CONSTEXPR
host_duplex_region::host_duplex_region(
	const T *send_data, 
	T *receive_data, 
	std::size_t count
) noexcept
	: m_send_data(send_data)
	, m_receive_data(receive_data)
	, m_data_type(numerical_type_of<T>::value)
	, m_count(count)
{
}

XMIPP4_INLINE_CONSTEXPR
host_duplex_region::host_duplex_region(
	const void *send_data, 
	void *receive_data, 
	numerical_type data_type, 
	std::size_t count
) noexcept
	: m_send_data(send_data)
	, m_receive_data(receive_data)
	, m_data_type(data_type)
	, m_count(count)
{
}

template <typename T>
XMIPP4_INLINE_CONSTEXPR
host_duplex_region::host_duplex_region(
	T *send_recv_data, 
	std::size_t count
) noexcept
	: m_send_data(send_recv_data)
	, m_receive_data(send_recv_data)
	, m_data_type(numerical_type_of<T>::value)
	, m_count(count)
{
}

XMIPP4_INLINE_CONSTEXPR
host_duplex_region::host_duplex_region(
	void *send_recv_data, 
	numerical_type data_type, 
	std::size_t count
) noexcept
	: m_send_data(send_recv_data)
	, m_receive_data(send_recv_data)
	, m_data_type(data_type)
	, m_count(count)
{
}

XMIPP4_INLINE_CONSTEXPR 
const void* host_duplex_region::get_send_data() const noexcept
{
	return m_send_data;
}	

XMIPP4_INLINE_CONSTEXPR
void* host_duplex_region::get_receive_data() const noexcept
{
	return m_receive_data;
}

XMIPP4_INLINE_CONSTEXPR 
numerical_type host_duplex_region::get_data_type() const noexcept
{
	return m_data_type;
}

XMIPP4_INLINE_CONSTEXPR 
std::size_t host_duplex_region::get_count() const noexcept
{
	return m_count;
}

} // namespace communication
} // namespace xmipp4
